const processedEmails = [];
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "Oktober", "November", "December"];
const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function updateReminders () {
	const emails = document.querySelectorAll(".zA");
	let lastLabel = null;
	
	for (const email of emails) {
		if (processedEmails.indexOf(email) != -1) continue;

		const nameNodes = email.querySelectorAll(".yP");
		let isReminder = false;

		for (const nameNode of nameNodes) {
			if (nameNode.innerText == "me") {
				nameNode.setAttribute("name", "Reminder");
				nameNode.innerHTML = "Reminder";
				isReminder = true;
			} else {
				isReminder = false;
				break;
			}
		}

		if (isReminder) {
			email.querySelectorAll(".y6,.Zt").forEach(node => node.outerHTML = "");
			email.querySelectorAll(".pH.a9q").forEach(node => {
				node.style.opacity = "1";
				node.style.backgroundImage = "url('https://gstatic.com/bt/C3341AA7A1A076756462EE2E5CD71C11/1x/ic_reminder_blue_24dp_r2.png')";
			});
			email.querySelectorAll(".y2").forEach(node => node.style.color = "#202124");
		}

		const dateString = email.querySelector(".xW.xY span").getAttribute("title");
		const date = new Date(dateString);
		const now = new Date();

		const addLabel = function (label) {
			if (!email.previousSibling || email.previousSibling.className != "time-row") {
				const timeRow = document.createElement("div");
				timeRow.className = "time-row";
				const time = document.createElement("div");
				time.className = "time";
				time.innerText = label;
				timeRow.appendChild(time);

				email.parentElement.insertBefore(timeRow, email);
			}
		};

		let label = "Last year";
		if (now.getFullYear() == date.getFullYear()) {
			label = months[date.getMonth()];

			if (now.getMonth() == date.getMonth()) {
				label = "This month";

				if (now.getDate() == date.getDate()) {
					label = "Today";
				} else if (now.getDate() == date.getDate() - 1) {
					label = "Yesterday";
				}
			}
		}

		if (label != lastLabel) {
			addLabel(label);
			lastLabel = label;
		}

		//processedEmails.push(email);
	}

	setTimeout(updateReminders, 100);
}

updateReminders();